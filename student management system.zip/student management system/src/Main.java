public class Main {
    public static void main(String[] args) {
        StudentManagementSystem sms = new StudentManagementSystem();

        // Add students
        sms.addStudent(new Student("Ali", 1, 85.5));
        sms.displayStudents(); // Display students after adding

        sms.addStudent(new Student("Sara", 2, 90.0));
        sms.displayStudents(); // Display students after adding

        // Add courses
        sms.addCourse(new Course("Math", 101));
        sms.displayCourses(); // Display courses after adding

        sms.addCourse(new Course("Physics", 102));
        sms.displayCourses(); // Display courses after adding

        // Edit a student
        sms.editStudent(1, "Ali Ahmed", 88.0);
        sms.displayStudents(); // Display students after editing

        // Calculate average grade
        System.out.println("\nAverage Grade: " + sms.calculateAverageGrade());

        // Delete a student
        sms.deleteStudent(2);
        sms.displayStudents(); // Display students after deletion
    }
}
