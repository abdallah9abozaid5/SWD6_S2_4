public class Student extends Person {
    private double grade;

    public Student(String name, int id, double grade) {
        super(name, id);
        this.grade = grade;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
}
